# RED GROCERY B2B - Cart + Checkout + Order Flow

Included:
- Cart model/service
- Add/remove/update quantity logic
- MOQ and stock validation
- Checkout screen
- Delivery address
- Payment method selection
- Firestore order creation
- Atomic stock decrement using transaction
- Order confirmation

Dependencies:
- firebase_core
- cloud_firestore

The cart service is intentionally lightweight. In the existing app, keep one CartService instance at app/session level so the cart survives navigation.

Production hardening is required before live orders: authenticated retailer checks, server-side credit validation, payment gateway/webhook, strict Firestore rules, and order audit logging.
