import 'package:cloud_firestore/cloud_firestore.dart';
import 'cart_models.dart';

class OrderRepository {
  final FirebaseFirestore db;
  OrderRepository({FirebaseFirestore? db}) : db = db ?? FirebaseFirestore.instance;

  Future<String> createOrder({
    required String retailerId,
    required List<CartItem> items,
    required String deliveryAddress,
    required String paymentMethod,
    String note = '',
  }) async {
    if (items.isEmpty) throw Exception('Cart is empty');

    final subtotal = items.fold<double>(0, (sum, i) => sum + i.lineTotal);
    final orderRef = db.collection('orders').doc();

    await db.runTransaction((tx) async {
      for (final item in items) {
        final productRef = db.collection('products').doc(item.productId);
        final snap = await tx.get(productRef);
        if (!snap.exists) throw Exception('${item.name} is unavailable');

        final stock = (snap.data()?['stock'] ?? 0) as int;
        if (stock < item.quantity) {
          throw Exception('Insufficient stock for ${item.name}');
        }

        tx.update(productRef, {
          'stock': stock - item.quantity,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }

      tx.set(orderRef, {
        'retailerId': retailerId,
        'items': items.map((i) => i.toMap()).toList(),
        'subtotal': subtotal,
        'total': subtotal,
        'deliveryAddress': deliveryAddress,
        'paymentMethod': paymentMethod,
        'paymentStatus': paymentMethod == 'credit' ? 'pending' : 'unpaid',
        'status': 'pending',
        'note': note,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });

    return orderRef.id;
  }
}
