class CartItem {
  final String productId;
  final String name;
  final String sku;
  final String packSize;
  final double unitPrice;
  final int quantity;
  final int stock;
  final int moq;
  final String imageUrl;

  const CartItem({
    required this.productId,
    required this.name,
    required this.sku,
    required this.packSize,
    required this.unitPrice,
    required this.quantity,
    required this.stock,
    required this.moq,
    required this.imageUrl,
  });

  CartItem copyWith({int? quantity}) => CartItem(
    productId: productId, name: name, sku: sku, packSize: packSize,
    unitPrice: unitPrice, quantity: quantity ?? this.quantity,
    stock: stock, moq: moq, imageUrl: imageUrl,
  );

  double get lineTotal => unitPrice * quantity;

  Map<String, dynamic> toMap() => {
    'productId': productId,
    'name': name,
    'sku': sku,
    'packSize': packSize,
    'unitPrice': unitPrice,
    'quantity': quantity,
    'lineTotal': lineTotal,
    'imageUrl': imageUrl,
  };
}
