import 'package:flutter/material.dart';
import 'cart_service.dart';
import 'order_repository.dart';

class CheckoutScreen extends StatefulWidget {
  final CartService cart;
  final String retailerId;
  const CheckoutScreen({super.key, required this.cart, required this.retailerId});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final address = TextEditingController();
  final note = TextEditingController();
  String paymentMethod = 'credit';
  bool submitting = false;

  Future<void> placeOrder() async {
    if (address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Delivery address is required')),
      );
      return;
    }

    setState(() => submitting = true);
    try {
      final id = await OrderRepository().createOrder(
        retailerId: widget.retailerId,
        items: widget.cart.items,
        deliveryAddress: address.text.trim(),
        paymentMethod: paymentMethod,
        note: note.text.trim(),
      );
      widget.cart.clear();
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Order Placed'),
          content: Text('Order ID: $id'),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Done'),
            ),
          ],
        ),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Order failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  void dispose() {
    address.dispose();
    note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextFormField(
            controller: address,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Delivery Address',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: paymentMethod,
            decoration: const InputDecoration(
              labelText: 'Payment Method',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'credit', child: Text('B2B Credit')),
              DropdownMenuItem(value: 'upi', child: Text('UPI')),
              DropdownMenuItem(value: 'cash_on_delivery', child: Text('Cash on Delivery')),
            ],
            onChanged: (v) => setState(() => paymentMethod = v ?? 'credit'),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: note,
            maxLines: 2,
            decoration: const InputDecoration(
              labelText: 'Order Note (optional)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Total: ₹${widget.cart.subtotal.toStringAsFixed(2)}',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: submitting ? null : placeOrder,
            child: Text(submitting ? 'Placing Order...' : 'Place Order'),
          ),
        ],
      ),
    );
  }
}
