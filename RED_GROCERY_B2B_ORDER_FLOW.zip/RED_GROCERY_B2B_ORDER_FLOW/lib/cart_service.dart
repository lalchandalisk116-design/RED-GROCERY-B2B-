import 'cart_models.dart';

class CartService {
  final Map<String, CartItem> _items = {};

  List<CartItem> get items => _items.values.toList();
  double get subtotal => items.fold(0, (sum, i) => sum + i.lineTotal);
  int get itemCount => items.fold(0, (sum, i) => sum + i.quantity);

  void add(CartItem item) {
    final existing = _items[item.productId];
    final qty = (existing?.quantity ?? 0) + item.quantity;
    if (qty > item.stock) throw Exception('Not enough stock');
    if (qty < item.moq) throw Exception('Minimum order quantity is ${item.moq}');
    _items[item.productId] = item.copyWith(quantity: qty);
  }

  void setQuantity(String productId, int qty) {
    final item = _items[productId];
    if (item == null) return;
    if (qty < item.moq) throw Exception('Minimum order quantity is ${item.moq}');
    if (qty > item.stock) throw Exception('Not enough stock');
    _items[productId] = item.copyWith(quantity: qty);
  }

  void remove(String productId) => _items.remove(productId);
  void clear() => _items.clear();
}
