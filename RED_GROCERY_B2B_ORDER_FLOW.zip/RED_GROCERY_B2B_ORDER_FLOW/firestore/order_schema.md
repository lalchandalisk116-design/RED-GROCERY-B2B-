# Order schema

orders/{orderId}

- retailerId: string
- items: array of item snapshots
- subtotal: number
- total: number
- deliveryAddress: string
- paymentMethod: credit | upi | cash_on_delivery
- paymentStatus: pending | unpaid | paid | failed
- status: pending | confirmed | packed | shipped | delivered | cancelled
- note: string
- createdAt: timestamp
- updatedAt: timestamp

Important:
Order creation uses a Firestore transaction to re-check product stock and decrement stock atomically. This prevents two retailers from buying the same final units simultaneously.

Before production:
- Add authenticated retailer authorization.
- Validate retailer credit limit server-side.
- Add payment gateway webhook for UPI.
- Restrict order writes with Firebase Security Rules or trusted backend logic.
- Consider Cloud Functions/server-side order numbering and audit logs.
