# RED GROCERY B2B - Catalog Module

This module starts the Product Catalog foundation for the existing project.

## Add dependencies
In `pubspec.yaml`:
- firebase_core
- cloud_firestore

## Firebase
Initialize Firebase in the existing app before using ProductRepository.

## Collections
See `firestore/schema.md`.

## First milestone
Admin can create/update `products/{productId}` and retailer catalog reads active products.
