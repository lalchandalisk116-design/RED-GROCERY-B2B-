# RED GROCERY B2B Firestore schema

## collections

### categories/{categoryId}
- name: string
- imageUrl: string
- sortOrder: number
- isActive: boolean
- createdAt: timestamp
- updatedAt: timestamp

### products/{productId}
- name: string
- categoryId: string
- brand: string
- sku: string
- packSize: string
- mrp: number
- b2bPrice: number
- moq: number
- stock: number
- gstPercent: number
- imageUrl: string
- isActive: boolean
- createdAt: timestamp
- updatedAt: timestamp

### products/{productId}/priceTiers/{tierId}
- minQty: number
- maxQty: number | null
- price: number

Example:
1-9 => 132
10-49 => 128
50+ => 124
