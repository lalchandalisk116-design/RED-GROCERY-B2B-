import 'package:flutter/material.dart';
import 'product_model.dart';

class CatalogScreen extends StatelessWidget {
  final Stream<List<Product>> products;
  const CatalogScreen({super.key, required this.products});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('RED GROCERY B2B')),
      body: StreamBuilder<List<Product>>(
        stream: products,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return const Center(child: Text('No products available'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            itemBuilder: (_, i) {
              final p = items[i];
              return Card(
                child: ListTile(
                  leading: p.imageUrl.isEmpty
                      ? const CircleAvatar(child: Icon(Icons.shopping_bag))
                      : CircleAvatar(backgroundImage: NetworkImage(p.imageUrl)),
                  title: Text(p.name),
                  subtitle: Text('${p.brand} • ${p.packSize}\nMOQ: ${p.moq} • Stock: ${p.stock}'),
                  isThreeLine: true,
                  trailing: Text('₹${p.b2bPrice.toStringAsFixed(2)}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
