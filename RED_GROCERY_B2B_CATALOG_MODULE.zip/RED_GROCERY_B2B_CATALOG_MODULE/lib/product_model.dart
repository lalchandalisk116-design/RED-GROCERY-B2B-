class Product {
  final String id;
  final String name;
  final String categoryId;
  final String brand;
  final String sku;
  final String packSize;
  final double mrp;
  final double b2bPrice;
  final int moq;
  final int stock;
  final double gstPercent;
  final String imageUrl;
  final bool isActive;

  const Product({
    required this.id,
    required this.name,
    required this.categoryId,
    required this.brand,
    required this.sku,
    required this.packSize,
    required this.mrp,
    required this.b2bPrice,
    required this.moq,
    required this.stock,
    required this.gstPercent,
    required this.imageUrl,
    required this.isActive,
  });

  factory Product.fromMap(String id, Map<String, dynamic> m) => Product(
    id: id,
    name: m['name'] ?? '',
    categoryId: m['categoryId'] ?? '',
    brand: m['brand'] ?? '',
    sku: m['sku'] ?? '',
    packSize: m['packSize'] ?? '',
    mrp: (m['mrp'] ?? 0).toDouble(),
    b2bPrice: (m['b2bPrice'] ?? 0).toDouble(),
    moq: (m['moq'] ?? 1) as int,
    stock: (m['stock'] ?? 0) as int,
    gstPercent: (m['gstPercent'] ?? 0).toDouble(),
    imageUrl: m['imageUrl'] ?? '',
    isActive: m['isActive'] ?? true,
  );
}
