import 'package:cloud_firestore/cloud_firestore.dart';
import 'product_model.dart';

class ProductRepository {
  final FirebaseFirestore db;
  ProductRepository({FirebaseFirestore? db}) : db = db ?? FirebaseFirestore.instance;

  Stream<List<Product>> activeProducts() {
    return db.collection('products')
      .where('isActive', isEqualTo: true)
      .snapshots()
      .map((snap) => snap.docs
        .map((doc) => Product.fromMap(doc.id, doc.data()))
        .toList());
  }

  Future<void> saveProduct(Map<String, dynamic> data, {String? id}) async {
    final ref = id == null
      ? db.collection('products').doc()
      : db.collection('products').doc(id);

    final payload = {
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
      if (id == null) 'createdAt': FieldValue.serverTimestamp(),
    };

    await ref.set(payload, SetOptions(merge: true));
  }
}
