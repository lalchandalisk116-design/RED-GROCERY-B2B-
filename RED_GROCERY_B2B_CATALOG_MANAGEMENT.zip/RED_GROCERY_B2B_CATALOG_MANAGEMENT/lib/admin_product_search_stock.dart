import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminProductSearchStock extends StatefulWidget {
  const AdminProductSearchStock({super.key});

  @override
  State<AdminProductSearchStock> createState() => _AdminProductSearchStockState();
}

class _AdminProductSearchStockState extends State<AdminProductSearchStock> {
  String query = '';
  String category = 'All';
  String brand = 'All';

  Query<Map<String, dynamic>> get baseQuery =>
      FirebaseFirestore.instance.collection('products').orderBy('name');

  Future<void> changeStock(DocumentSnapshot<Map<String, dynamic>> doc) async {
    final c = TextEditingController(text: '${doc.data()?['stock'] ?? 0}');
    final value = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Update Stock: ${doc.data()?['name'] ?? ''}'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'New stock quantity'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(context, int.tryParse(c.text)),
            child: const Text('Update'),
          ),
        ],
      ),
    );
    if (value == null || value < 0) return;
    await doc.reference.update({
      'stock': value,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  bool matches(Map<String, dynamic> d) {
    final haystack = '${d['name'] ?? ''} ${d['brand'] ?? ''} ${d['sku'] ?? ''}'.toLowerCase();
    final q = query.trim().toLowerCase();
    final textOk = q.isEmpty || haystack.contains(q);
    final categoryOk = category == 'All' || d['categoryId'] == category;
    final brandOk = brand == 'All' || d['brand'] == brand;
    return textOk && categoryOk && brandOk;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Product Search & Stock')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: baseQuery.snapshots(),
        builder: (_, snapshot) {
          final docs = snapshot.data?.docs.where((d) => matches(d.data())).toList() ?? [];
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Search name, brand or SKU',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final doc = docs[i];
                    final d = doc.data();
                    return ListTile(
                      title: Text(d['name'] ?? ''),
                      subtitle: Text('${d['brand'] ?? ''} • SKU: ${d['sku'] ?? ''}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('Stock: ${d['stock'] ?? 0}'),
                          IconButton(
                            icon: const Icon(Icons.inventory_2_outlined),
                            onPressed: () => changeStock(doc),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
