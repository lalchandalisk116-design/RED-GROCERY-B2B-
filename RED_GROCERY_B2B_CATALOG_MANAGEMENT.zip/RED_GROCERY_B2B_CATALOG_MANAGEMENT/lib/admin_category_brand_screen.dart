import 'package:flutter/material.dart';
import 'category_brand_repository.dart';

class AdminCategoryBrandScreen extends StatefulWidget {
  const AdminCategoryBrandScreen({super.key});

  @override
  State<AdminCategoryBrandScreen> createState() =>
      _AdminCategoryBrandScreenState();
}

class _AdminCategoryBrandScreenState extends State<AdminCategoryBrandScreen> {
  final repo = CatalogManagementRepository();

  Future<void> addCategory() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Category'),
        content: TextField(controller: controller, decoration: const InputDecoration(labelText: 'Category name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Save')),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) await repo.saveCategory(name: name);
  }

  Future<void> addBrand() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Brand'),
        content: TextField(controller: controller, decoration: const InputDecoration(labelText: 'Brand name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Save')),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) await repo.saveBrand(name: name);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Categories & Brands')),
      body: Row(
        children: [
          Expanded(
            child: _listPanel(
              title: 'Categories',
              stream: repo.categories.orderBy('sortOrder').snapshots(),
              onAdd: addCategory,
            ),
          ),
          Expanded(
            child: _listPanel(
              title: 'Brands',
              stream: repo.brands.orderBy('name').snapshots(),
              onAdd: addBrand,
            ),
          ),
        ],
      ),
    );
  }

  Widget _listPanel({
    required String title,
    required Stream stream,
    required VoidCallback onAdd,
  }) {
    return Card(
      margin: const EdgeInsets.all(12),
      child: Column(
        children: [
          ListTile(title: Text(title), trailing: IconButton(onPressed: onAdd, icon: const Icon(Icons.add))),
          Expanded(
            child: StreamBuilder(
              stream: stream,
              builder: (_, snapshot) {
                final docs = snapshot.data?.docs ?? [];
                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final d = docs[i];
                    return ListTile(
                      title: Text(d.data()['name'] ?? ''),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => d.reference.delete(),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
