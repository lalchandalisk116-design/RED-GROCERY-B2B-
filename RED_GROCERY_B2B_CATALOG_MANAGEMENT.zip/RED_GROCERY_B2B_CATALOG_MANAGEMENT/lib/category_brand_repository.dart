import 'package:cloud_firestore/cloud_firestore.dart';

class CatalogManagementRepository {
  final FirebaseFirestore db;
  CatalogManagementRepository({FirebaseFirestore? db})
      : db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get categories =>
      db.collection('categories');

  CollectionReference<Map<String, dynamic>> get brands =>
      db.collection('brands');

  CollectionReference<Map<String, dynamic>> get products =>
      db.collection('products');

  Future<void> saveCategory({
    String? id,
    required String name,
    String imageUrl = '',
    int sortOrder = 0,
  }) async {
    final ref = id == null ? categories.doc() : categories.doc(id);
    await ref.set({
      'name': name.trim(),
      'imageUrl': imageUrl,
      'sortOrder': sortOrder,
      'isActive': true,
      'updatedAt': FieldValue.serverTimestamp(),
      if (id == null) 'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> deleteCategory(String id) => categories.doc(id).delete();

  Future<void> saveBrand({String? id, required String name}) async {
    final ref = id == null ? brands.doc() : brands.doc(id);
    await ref.set({
      'name': name.trim(),
      'isActive': true,
      'updatedAt': FieldValue.serverTimestamp(),
      if (id == null) 'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> deleteBrand(String id) => brands.doc(id).delete();

  Future<void> updateStock(String productId, int newStock) async {
    if (newStock < 0) throw ArgumentError('Stock cannot be negative');
    await products.doc(productId).update({
      'stock': newStock,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
