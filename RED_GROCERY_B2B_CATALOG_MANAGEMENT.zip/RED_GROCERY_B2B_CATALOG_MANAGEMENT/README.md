# RED GROCERY B2B - Catalog Management

Added:
- Category create/delete
- Brand create/delete
- Product search by name, brand, SKU
- Stock update dialog
- Firestore repository

Recommended next hardening:
- Admin-only Firebase Security Rules/custom claims
- Edit category/brand
- Category/brand dropdowns in Product Form
- Server-side pagination for large catalogs
- Low-stock threshold and alerts
- Audit log for stock changes
