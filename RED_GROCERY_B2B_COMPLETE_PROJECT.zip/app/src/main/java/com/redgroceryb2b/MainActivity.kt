package com.redgroceryb2b

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Product(val id:String,val name:String,val pack:String,val price:Int,val stock:Int,val category:String)
data class CartLine(val product:Product,var qty:Int)

val sampleProducts = listOf(
 Product("P001","Fortune Rice","25 kg",1250,80,"Rice"),
 Product("P002","Toor Dal","10 kg",980,60,"Dal"),
 Product("P003","Fortune Sunflower Oil","15 L",1850,40,"Oil"),
 Product("P004","Aashirvaad Atta","10 kg",520,90,"Atta"),
 Product("P005","Parle-G Biscuit","1 carton",310,120,"Biscuit"),
 Product("P006","Tata Tea","1 carton",620,70,"Beverage"),
 Product("P007","Surf Excel","1 carton",1180,45,"Home Care"),
 Product("P008","Lux Soap","1 carton",740,55,"Personal Care")
)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GroceryApp() }
    }
}

@Composable
fun GroceryApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("Home") }
    var cart by remember { mutableStateOf(listOf<CartLine>()) }
    var orderPlaced by remember { mutableStateOf(false) }

    if (!loggedIn) {
        LoginScreen { loggedIn = true }
        return
    }

    val total = cart.sumOf { it.product.price * it.qty }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("RED GROCERY B2B", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Home","Cart","Orders","Profile").forEach { name ->
                    NavigationBarItem(
                        selected = page == name,
                        onClick = { page = name },
                        icon = {},
                        label = { Text(name) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(14.dp)) {
            when(page) {
                "Home" -> HomeScreen(
                    products = sampleProducts,
                    onAdd = { p ->
                        val old = cart.find { it.product.id == p.id }
                        cart = if (old == null) cart + CartLine(p,1)
                        else cart.map { if (it.product.id == p.id) it.copy(qty=it.qty+1) else it }
                    }
                )
                "Cart" -> CartScreen(cart, total, onCheckout = { page="Orders"; orderPlaced=true })
                "Orders" -> OrdersScreen(orderPlaced)
                "Profile" -> ProfileScreen()
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin:()->Unit) {
    var mobile by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(com.redgroceryb2b.R.drawable.red_grocery_logo),
            contentDescription = "RED GROCERY B2B",
            modifier = Modifier.size(190.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text("Retailer Login", fontSize=24.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(mobile, { mobile=it }, label={Text("Mobile Number")}, singleLine=true)
        Spacer(Modifier.height(14.dp))
        Button(
            onClick=onLogin,
            enabled=mobile.length >= 10,
            modifier=Modifier.fillMaxWidth()
        ) { Text("Login / OTP") }
    }
}

@Composable
fun HomeScreen(products:List<Product>, onAdd:(Product)->Unit) {
    Text("Wholesale Grocery", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
    Text("Retailer prices • MOQ • Live stock", modifier=Modifier.padding(vertical=6.dp))
    LazyColumn {
        items(products) { p ->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) {
                Row(Modifier.padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight=FontWeight.Bold)
                        Text("${p.pack}  •  Stock ${p.stock}")
                        Text("Wholesale ₹${p.price}", fontWeight=FontWeight.Bold)
                    }
                    Button(onClick={onAdd(p)}) { Text("Add") }
                }
            }
        }
    }
}

@Composable
fun CartScreen(cart:List<CartLine>, total:Int, onCheckout:()->Unit) {
    Text("Cart", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
    if(cart.isEmpty()) Text("Your cart is empty.")
    else {
        cart.forEach { line ->
            Text("${line.product.name} × ${line.qty}  ₹${line.product.price*line.qty}",
                modifier=Modifier.padding(vertical=7.dp))
        }
        Divider(Modifier.padding(vertical=8.dp))
        Text("Grand Total: ₹$total", fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Payment: UPI / Online / Credit Account")
        Spacer(Modifier.height(12.dp))
        Button(onClick=onCheckout, modifier=Modifier.fillMaxWidth()) { Text("Place Order") }
    }
}

@Composable
fun OrdersScreen(placed:Boolean) {
    Text("Order Tracking", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    if(!placed) Text("No orders yet.")
    else {
        Text("Order #RGB2B-1001", fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("🟢 Order Confirmed")
        Text("🟠 Processing")
        Text("🔵 Dispatch")
        Text("⚪ Delivered")
        Spacer(Modifier.height(12.dp))
        Text("Invoice available after confirmation.")
    }
}

@Composable
fun ProfileScreen() {
    Text("Retailer Profile", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Text("Business: Demo Retail Store")
    Text("Credit Limit: ₹50,000")
    Text("Outstanding: ₹0")
    Text("Payment History")
    Text("Addresses")
}
