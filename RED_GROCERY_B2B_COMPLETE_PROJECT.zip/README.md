# RED GROCERY B2B - Complete Setup

## Included
1. Android retailer app project
2. RED GROCERY B2B supplied logo
3. Admin panel starter UI
4. Firestore security rules
5. Firestore schema
6. Wholesale product/cart/order workflow

## Android build
Open this folder in Android Studio and sync Gradle.
Then: Build > Generate App Bundle(s) / APK(s) > Generate APK(s).

## Firebase connection
Create a Firebase project, enable Phone Authentication and Firestore, then add
your Android app with package name `com.redgroceryb2b`. Download `google-services.json`
into `app/` and add the Google Services Gradle plugin/dependency before enabling Firebase SDK calls.

## Production requirements
- Configure Firebase Phone Auth / OTP
- Create admin custom claim `admin=true` using a secure server/Cloud Function
- Connect UPI/payment gateway
- Add GST/invoice logic
- Add real image storage
- Add push notifications
- Configure delivery/dispatch operations
- Never ship admin secrets inside the APK
