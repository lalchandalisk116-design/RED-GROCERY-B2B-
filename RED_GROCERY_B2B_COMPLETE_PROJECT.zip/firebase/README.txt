Firebase setup:
1. Create Firebase project named RED GROCERY B2B.
2. Add Android package: com.redgroceryb2b.
3. Enable Phone Authentication.
4. Create Firestore Database.
5. Deploy firestore.rules.
6. Add admin custom claim using a trusted server/Cloud Function.
7. For production payments, use a server-side verified payment gateway flow.
