# RED GROCERY B2B Firestore Schema

## retailers/{uid}
name, businessName, phone, address, gstin, creditLimit, outstanding, approved, createdAt

## products/{productId}
name, categoryId, packSize, wholesalePrice, mrp, moq, stock, active, imageUrl, createdAt

## categories/{categoryId}
name, imageUrl, active, sortOrder

## orders/{orderId}
retailerId, items[], subtotal, gst, deliveryCharge, total, paymentMethod, paymentStatus,
orderStatus, deliveryAddress, createdAt, updatedAt

orderStatus: confirmed | processing | dispatched | delivered | cancelled

## payments/{paymentId}
retailerId, orderId, amount, method, status, reference, createdAt

## Admin
Use Firebase custom claims: admin=true. Never put admin credentials in the Android app.
