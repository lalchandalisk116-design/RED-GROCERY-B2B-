# RED GROCERY B2B Admin Product Module

Included:
- Add Product
- Edit Product
- Delete Product with confirmation
- Product image upload foundation using Firebase Storage
- Admin product list
- Firestore persistence

Dependencies:
- firebase_core
- cloud_firestore
- firebase_storage

Image picker integration:
`AdminProductForm` contains `imageBytes` and the Firebase Storage upload logic. Connect `imageBytes` to `image_picker` (mobile) or `file_picker` (web/desktop) according to the target platform.

Security:
The example Storage rule requires authentication for writes. In production, restrict writes to admin users using a custom claim such as `admin == true`.
