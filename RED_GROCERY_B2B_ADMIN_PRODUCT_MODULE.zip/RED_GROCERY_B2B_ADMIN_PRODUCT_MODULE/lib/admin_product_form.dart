import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class AdminProductForm extends StatefulWidget {
  final String? productId;
  final Map<String, dynamic>? initialData;

  const AdminProductForm({super.key, this.productId, this.initialData});

  @override
  State<AdminProductForm> createState() => _AdminProductFormState();
}

class _AdminProductFormState extends State<AdminProductForm> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _category = TextEditingController();
  final _brand = TextEditingController();
  final _sku = TextEditingController();
  final _packSize = TextEditingController();
  final _mrp = TextEditingController();
  final _b2b = TextEditingController();
  final _moq = TextEditingController(text: '1');
  final _stock = TextEditingController(text: '0');
  final _gst = TextEditingController(text: '0');
  final _imageUrl = TextEditingController();

  Uint8List? imageBytes;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    final d = widget.initialData ?? {};
    _name.text = d['name'] ?? '';
    _category.text = d['categoryId'] ?? '';
    _brand.text = d['brand'] ?? '';
    _sku.text = d['sku'] ?? '';
    _packSize.text = d['packSize'] ?? '';
    _mrp.text = '${d['mrp'] ?? ''}';
    _b2b.text = '${d['b2bPrice'] ?? ''}';
    _moq.text = '${d['moq'] ?? 1}';
    _stock.text = '${d['stock'] ?? 0}';
    _gst.text = '${d['gstPercent'] ?? 0}';
    _imageUrl.text = d['imageUrl'] ?? '';
  }

  @override
  void dispose() {
    for (final c in [_name,_category,_brand,_sku,_packSize,_mrp,_b2b,_moq,_stock,_gst,_imageUrl]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      String imageUrl = _imageUrl.text.trim();

      // Connect your image picker/web file selector here and assign imageBytes.
      // Storage upload:
      if (imageBytes != null) {
        final id = widget.productId ??
            FirebaseFirestore.instance.collection('products').doc().id;
        final ref = FirebaseStorage.instance.ref('products/$id.jpg');
        await ref.putData(imageBytes!, SettableMetadata(contentType: 'image/jpeg'));
        imageUrl = await ref.getDownloadURL();
      }

      final data = {
        'name': _name.text.trim(),
        'categoryId': _category.text.trim(),
        'brand': _brand.text.trim(),
        'sku': _sku.text.trim(),
        'packSize': _packSize.text.trim(),
        'mrp': double.parse(_mrp.text),
        'b2bPrice': double.parse(_b2b.text),
        'moq': int.parse(_moq.text),
        'stock': int.parse(_stock.text),
        'gstPercent': double.parse(_gst.text),
        'imageUrl': imageUrl,
        'isActive': true,
        'updatedAt': FieldValue.serverTimestamp(),
      };

      final ref = widget.productId == null
          ? FirebaseFirestore.instance.collection('products').doc()
          : FirebaseFirestore.instance.collection('products').doc(widget.productId);

      if (widget.productId == null) data['createdAt'] = FieldValue.serverTimestamp();
      await ref.set(data, SetOptions(merge: true));

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(widget.productId == null
              ? 'Product added successfully'
              : 'Product updated successfully')),
        );
        Navigator.pop(context);
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> deleteProduct() async {
    if (widget.productId == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete product?'),
        content: const Text('This will permanently remove the product document.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;

    await FirebaseFirestore.instance.collection('products').doc(widget.productId).delete();
    if (mounted) Navigator.pop(context);
  }

  Widget field(TextEditingController c, String label, {TextInputType? type, bool required = true}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: type,
        validator: required ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null : null,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.productId != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? 'Edit Product' : 'Add Product'),
        actions: [
          if (editing)
            IconButton(onPressed: deleteProduct, icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            field(_name, 'Product Name'),
            field(_category, 'Category ID'),
            field(_brand, 'Brand'),
            field(_sku, 'SKU'),
            field(_packSize, 'Pack Size'),
            field(_mrp, 'MRP', type: TextInputType.number),
            field(_b2b, 'B2B Price', type: TextInputType.number),
            field(_moq, 'Minimum Order Quantity', type: TextInputType.number),
            field(_stock, 'Stock', type: TextInputType.number),
            field(_gst, 'GST %', type: TextInputType.number),
            field(_imageUrl, 'Image URL', required: false),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () {
                // TODO: wire image picker/file picker and set imageBytes.
              },
              icon: const Icon(Icons.image_outlined),
              label: const Text('Choose Product Image'),
            ),
            if (imageBytes != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Image.memory(imageBytes!, height: 160, fit: BoxFit.cover),
              ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: saving ? null : save,
              child: Text(saving ? 'Saving...' : editing ? 'Update Product' : 'Add Product'),
            ),
          ],
        ),
      ),
    );
  }
}
